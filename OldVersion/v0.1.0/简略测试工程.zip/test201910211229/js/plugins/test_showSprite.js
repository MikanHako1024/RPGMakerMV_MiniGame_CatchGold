//=============================================================================
// test_showSprite.js
//  last update: 2019/09/26
//=============================================================================


console.log("load success : test_showSprite");



/*
 * MikanTest_showSprite.showSprite(sprite)
 * MikanTest_showSprite.clear()
 * MikanTest_showSprite.setDiyColor(color)
 * 
 * 
 */


/*
 * ？待 窗口变化时 重置canvas宽高 ...
 * 
 */





/*
function MikanTest_showSprite() {
    throw new Error('This is a static class');
}

MikanTest_showSprite.canvasList = [];


MikanTest_showSprite.canvasNum = function() {
	return this.canvasList.length;
}

MikanTest_showSprite.lastId = -1;
MikanTest_showSprite._addCanvas = function(canvas) {

	document.getElementsByTagName('body')[0].appendChild(canvas);
	this.canvasList.push(canvas);
	this.lastId = canvasNum - 1;
}

MikanTest_showSprite._createTestCanvas = function() {

	var canvas = document.createElement('canvas');
	var newId = canvasNum;
	canvas.id = 'MikanTest_showSprite_canvas_' + (newId+1);
	canvas.width = window.innerWidth/2;
	canvas.height = window.innerHeight/2;
	canvas.style.zIndex = 22;
	canvas.style.position = 'absolute';
	canvas.style.left = ( [0, 1, 0, 1][newId%4] * canvas.width ) + 'px'; 
		// ？或 直接用百分比 [0, '50%', 0, '50%'][newId%4] ...
	canvas.style.top  = ( [0, 0, 1, 1][newId%4] * canvas.height ) + 'px'; 
		// ？或 直接用百分比 [0, '0, 50%', '50%'][newId%4] ...

	this.addCanvas(canvas);
}


MikanTest_showSprite.showSprite = function(sprite, id) {

	if (!sprite) return ;
	if (this.lastId==-1) this._createTestCanvas();

	id = id || this.lastId;
	id = id<this.canvasNum() ? id : this.lastId;

	this.putSpriteToCanvas(sprite, this.canvasList[id]);
}

MikanTest_showSprite.putSpriteToCanvas = function(sprite, canvas) {

	if (!sprite) return ;
	if (!canvas) return ;

	var ctx = canvas.getContext('2d');

}
*/
// ？改 分为4个显示 ...
// ？为 直接在整个窗口显示 ...


function MikanTest_showSprite() {
    //throw new Error('This is a static class');
    throw new Error('This is a static class');
}


MikanTest_showSprite.initialize = function() {

	this._createCanvas();

	//this.isNeedWhiteBoard = true;
	// ？...
	this._boardMode = this.WHITE_BOARD;

	this._diyColor = '#FFFFFF00';
};
// ？initialize 不会自动执行 ...

//MikanTest_showSprite.initialize();
// ？错了 此时方法未加载完 ...



MikanTest_showSprite.NONE_BOARD   = 0;
MikanTest_showSprite.WHITE_BOARD  = 1;
MikanTest_showSprite.BLACK_BOARD  = 2;
MikanTest_showSprite.DIY_BOARD    = 3;



MikanTest_showSprite._createCanvas = function() {

	var canvas = document.createElement('canvas');

	canvas.id = 'MikanTest_showSprite_canvas';
	canvas.width = window.innerWidth;
	canvas.height = window.innerHeight;
	//canvas.style.zIndex = 22;
	canvas.style.zIndex = '22'; // ？值应该是字符串 否则将是0 ...
	canvas.style.position = 'absolute';
	canvas.style.left = 0;
	canvas.style.top  = 0;

	this.canvas = canvas;
	this.context = canvas.getContext('2d');

	document.getElementsByTagName('body')[0].appendChild(canvas);
};


MikanTest_showSprite.showSprite = function(sprite, x, y) {
			// ？允许改变 初始x, y ...

	//console.log(sprite);

	if (!sprite) return ;
	//if (!sprite.bitmap) return ;

	this._drawBoard();
	//this._drawSprite(sprite);
	
	//this._findSprite(sprite, 0, 0);

	x = x || 0;
	y = y || 0;
	this._findSprite(sprite, x, y);

	// ？传入容器时 递归地 全部画出 ...
};

MikanTest_showSprite.quicklyShowScene = function(path, x, y) {

	//var str = 'SceneManager._scene';
	//if (!eval(str)) return ;
	//
	//var idx = 0;
	//while (path[idx] && !eval(str + '.children[' + path[idx] + ']')) {
	//	str += '.children[' + path[idx] + ']';
	//	idx++;
	//}
	//console.log(str);
	//
	//this.showSprite(eval(str));

	this.showSprite(this._getSceneSprite(path), x, y);
};

MikanTest_showSprite._getSceneSprite = function(path) {

	var str = 'SceneManager._scene';
	//if (!eval(str)) return ;

	var idx = 0;
	//while (path[idx] && eval(str + '.children[' + path[idx] + ']')) {
		// ？ 0 是false ...
	while (idx<path.length && path[idx]!==undefined && eval(str + '.children[' + path[idx] + ']')) {
		str += '.children[' + path[idx] + ']';
		idx++;
	}
	//console.log(str);

	return eval(str);
};

MikanTest_showSprite.getSceneSprite_real = function(path) {
		// ？防止 因处理了错误 而看不到真正的对象 ...

	var str = 'SceneManager._scene';

	var idx = 0;
	while (path[idx]!==undefined) {
		str += '.children[' + path[idx] + ']';
		idx++;
	}
	//console.log(str);

	return eval(str);
};


// [1,4,3,] ？？
// WindowLayer - Window_EquipSlotItem - Sprite - Sprite_Bust / Sprite

// === berak  201909252309  ===



MikanTest_showSprite.clear = function() {
	this._clearCanvas();
};

MikanTest_showSprite.setShowMode = function(mode) {
	this._boardMode = mode;

	if (mode==this.NONE_BOARD || mode==this.DIY_BOARD) {
		this.clear();
	}
	// ？背景图是透明的 不能覆盖原有的画面 所以要单独清除 ...
	// ？DIY背景也可能是透明的 ...
};



MikanTest_showSprite._getBoardColor = function() {

	switch(this._boardMode) {
		case this.NONE_BOARD: return '#FFFFFF00';
		case this.WHITE_BOARD: return '#FFFFFFFF';
		case this.BLACK_BOARD: return '#000000FF';
		case this.DIY_BOARD: return this._getDiyColor();
		default: return '#FFFFFF00';
	}

	// ？或 用数组 ...
};

MikanTest_showSprite._getDiyColor = function () {
	return this._diyColor;
};

MikanTest_showSprite.setDiyColor = function (color) {
	this._diyColor = color || '#FFFFFF00';
};


MikanTest_showSprite._clearCanvas = function() {
	var x = 0;
	var y = 0;
	var w = this.canvas.width;
	var h = this.canvas.height;
	this.context.clearRect(x, y, w, h);
};

MikanTest_showSprite._drawBoard = function() {
	var x = 0;
	var y = 0;
	var w = this.canvas.width;
	var h = this.canvas.height;
	this.context.fillStyle = this._getBoardColor();
	this.context.fillRect(x, y, w, h);
};

//MikanTest_showSprite._drawSprite = function(sprite) {
//	var x = sprite.x;
//	var y = sprite.y;
//	var w = sprite.bitmap.width;
//	var h = sprite.bitmap.height;
//	this.context.drawImage(sprite.bitmap.canvas, x, y, w, h);
//};
// ？传入容器时 递归地 全部画出 ...

//MikanTest_showSprite._findSprite = function(sprite) {
MikanTest_showSprite._findSprite = function(sprite, amendX, amendY) {

	if (!sprite) return ;

	if (sprite.bitmap) {
		this._drawSprite(sprite, amendX, amendY);
	}

	if (sprite.children && sprite.children.length>0) {
		//sprite.children.forEach(function(sprite) {
		//});
		// ？这样 this 就不是 MikanTest_showSprite 了 ...
		for (var idx=0; idx<sprite.children.length; idx++) {
			this._findSprite(sprite.children[idx], 
					amendX+sprite.x, amendY+sprite.y);
		}
	}
};

//MikanTest_showSprite._drawSprite = function(sprite) {
MikanTest_showSprite._drawSprite = function(sprite, amendX, amendY) {

	//console.log(sprite);

	var x = sprite.x + amendX;
	var y = sprite.y + amendY;
	var w = sprite.bitmap.width;
	var h = sprite.bitmap.height;

	//this.context.drawImage(sprite.bitmap.canvas, x, y, w, h);

	var frame = sprite._frame;
	var fx = frame.x;
	var fy = frame.y;
	var fw = frame.width;
	var fh = frame.height;

	this.context.drawImage(sprite.bitmap.canvas, fx, fy, fw, fh, x, y, w, h);
};

// ？sprite的x, y是相对其容器的 ...

// ？还要考虑 sprite 的 frame ...
// ？还要考虑 sprite 的 anchor ...
// ？还要考虑 sprite 的 scale ...
// ？还要考虑 sprite 的 pivot ...



// ？允许设置 x, y 防止画到画布外 ...
	// ？因为直接画子项没有amendX|Y ...


// ？允许只画sprite本身 不进行递归 ....
// showSpriyte_only


// ？允许不清除 而是暂时关闭 ...
// turnOn, turnOff
// MikanTest_showSprite.canvas.hidden = false     true


// ？改名为 quicklyGetSprite ...






// ？直接设置宽高 实现清除 ...

// ？每次操作都要 清除重绘 ...

// ？背景？板子 board



// ？可以直接 容器.x|y 找容器的位置 ...




(function() {

	//MikanTest_showSprite.initialize();
})();


