//=============================================================================
// test_callDebug.js
//  last update: 2019/09/25
//=============================================================================


console.log("load success : test_callDebug");


(function() {
	require('nw.gui').Window.get().showDevTools();
})();

